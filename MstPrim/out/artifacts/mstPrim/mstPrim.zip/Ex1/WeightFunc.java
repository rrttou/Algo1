package Ex1;

public interface WeightFunc {
    int weight(Node a, Node b); //abstract method weight
}
